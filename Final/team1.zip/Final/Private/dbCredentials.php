<?php
define("DB_SERVER", "localhost");
define("DB_USER", "team1" );
define("DB_PWD", "steam1");
define("DB_NAME", "team1");
?>
