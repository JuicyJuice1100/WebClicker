<?php 
    echo json_encode(getQuestionSubmissions(7));
?>