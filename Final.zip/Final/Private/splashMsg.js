
(function option(id) {
  return document.getElementById(id).innerHTML;   
})();


