Author: David Dunkovich, Justin Espritu, Jacob Seymer, Calvin Meier
Date: 11/7/2017
Instructions:
Start on sign_in.html which is the single entry point
for the student and instructor. Click on either instructor
or student, then log in. Thanks!
